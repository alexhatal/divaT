
$(document).ready(function() { t280_showMenu('298325601'); t280_changeSize('298325601');	t280_highlight(); }); $(window).resize(function() { t280_changeSize('298325601'); }); 
      
$(document).ready(function() { setTimeout(function(){ t_onFuncLoad('t_menusub_init', function() { t_menusub_init('298325601'); }); }, 500); });

$( document ).ready(function() { t396_init('298324275');
        });

$( document ).ready(function() { t396_init('299872676');
    });

$( document ).ready(function() { t396_init('298603488');
});

$( document ).ready(function() { t396_init('298413719');
        });

$(document).ready(function() { t505__createPieChart('299892115','74','6','75','','#ff225c','#2a006b','#d8c4ff','3','15','160'); });

$( document ).ready(function() { t396_init('298604009');
        });

$(document).ready(function(){ var typography_optsObj = { title: "color:#ff225c;", descr: "color:#2a006b;", subtitle: "" }; var separator_optsObj = { height: '', color: '', opacity: '', hideSeparator: false }; var popup_optsObj = { popupBgColor: '', overlayBgColorRgba: '', closeText: '', iconColor: '', popupStat: '', titleColor: '', textColor: '', subtitleColor: '', datePos: 'aftertitle', partsPos: 'aftertitle', imagePos: 'aftertitle', inTwoColumns: false, zoom: false, styleRelevants: '', methodRelevants: 'random', titleRelevants: '', showRelevants: '', shareStyle: '', shareBg: '', isShare: false, shareServices: '', shareFBToken: '', showDate: true, bgSize: 'cover' }; var arrowtop_optsObj = { isShow: true, style: '', color: '#ff225c', bottom: '', left: '', right: '' }; var parts_optsObj = { partsBgColor: '', partsBorderSize: '1px', partsBorderColor: '#ffffff', align: 'center' }; var gallery_optsObj = { control: '', arrowSize: '', arrowBorderSize: '', arrowColor: '', arrowColorHover: '', arrowBg: '', arrowBgHover: '', arrowBgOpacity: '', arrowBgOpacityHover: '', showBorder: '', dotsWidth: '', dotsBg: '', dotsActiveBg: '', dotsBorderSize: '' }; var btnAllPosts_optsObj = { text: '', link: '', target: '' };	var colWithBg_optsObj = {	paddingSize: '',	background: '#ffffff',	borderRadius: '20px',	shadowSize: '',	shadowOpacity: '',	shadowSizeHover: '10px',	shadowOpacityHover: '40',	shadowShiftyHover: 'sm' }; var options = { feeduid: '824215347661', previewmode: 'yes', align: 'left', amountOfPosts: '3', reverse: 'desc', blocksInRow: '3', blocksClass: 't-feed__grid-col t-col t-col_4', blocksWidth: '360', colClass: '', prefixClass: '', vindent: '', dateFormat: '4', timeFormat: '', imageRatio: '75', hasOriginalAspectRatio: false, imageHeight: '', imageWidth: '', dateFilter: 'all', showPartAll: true, showImage:true, showShortDescr:true, showParts:true, showDate:true, hideFeedParts: false, parts_opts: parts_optsObj, btnsAlign: false, colWithBg: colWithBg_optsObj, separator: separator_optsObj, btnAllPosts: btnAllPosts_optsObj, popup_opts: popup_optsObj, arrowtop_opts: arrowtop_optsObj, gallery: gallery_optsObj, typo: typography_optsObj, amountOfSymbols: '', bbtnStyle: 'color:#ffffff;background-color:#ff225c;border-radius:50px; -moz-border-radius:50px; -webkit-border-radius:50px;font-family:FuturaPT;', btnStyle: 'color:#ffffff;background-color:#ff225c;border-radius:50px; -moz-border-radius:50px; -webkit-border-radius:50px;', btnTextColor: '#ffffff', btnType: '', btnSize: '', btnText: 'Další články', btnReadMore: '', isHorizOnMob:false, itemsAnim: 'zoomin', datePosPs: 'beforetitle', partsPosPs: 'beforetitle', imagePosPs: 'beforetitle', datePos: 'afterdescr', partsPos: 'onimage', imagePos: 'beforetitle' }; t_onFuncLoad('t_feed_init', function() { t_feed_init('302476639', options); }); $('#rec302476639').find('.t915__container_mobile-flex').bind('touchstart', function() { $('#rec302476639').find('.t-col').bind('touchmove', function() { if (typeof $(".t-records").attr('data-tilda-mode') == 'undefined') { if (window.lazy === 'y' || $('#allrecords').attr('data-tilda-lazy') === 'yes') { t_onFuncLoad('t_lazyload_update', function () { t_lazyload_update(); }); } } }); }).mouseup(function() { $('#rec302476639').find('.t-col').unbind('touchend'); });
            });

$(document).ready(function() {	jQuery.cachedScript = function( url ) { var options = { dataType: "script", cache: true, url: url }; return jQuery.ajax( options );	};	$.cachedScript("js/tilda-zero-forms-1.0.min.js").done(function( script, textStatus ) {	if(textStatus=='success'){	setTimeout(function(){	var recid='298420502';	var elemid='1570628150635';	t_zeroForms__init(recid,elemid);	},500);	}else{	console.log('Error init form in zeroblock. Err:'+textStatus);	}	});	});

$( document ).ready(function() { t396_init('298420502');
            });